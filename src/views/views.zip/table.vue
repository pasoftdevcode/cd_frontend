<template>
    <div class="row">
        <div v-for="(item, index) in dich_vu" :key="index">
            <thuocTinh :name="item.name" :subName="item.subName" :thuocTinh_id="index"> </thuocTinh>
        </div>
        <!-- /* =============== > Mở rộng < =============== */ -->
        <center style="margin: 12px auto 0">
            <button class="btn btn-primary" type="button">Mở rộng</button>
        </center>
    </div>
</template>
<script>
    import thuocTinh from '@/views/thuocTinh.vue';

    export default {
        name: 'table',
        components: {
            thuocTinh
        },//components
        data(){
            return {
                dich_vu:[
                    {name: '15k'},
                    {name: '17k'},
                    {name: '15k', subName: '17k'},
                    {name: '23k',},
                    {name: 'SJC', moRong: true},
                    {name: '9999', moRong: true},
                    {name: 'BK', moRong: true},
                ],
            }
        },//data
    }
</script>
<style type="text/css">
tbody > tr > td > input, thead > tr{
    text-align: center;
}
.loai{
    background-color: #d2d2d2;
}
.luong{
    background-color: #e2e2e2;
}

.block_camdo{
    position: relative;
    margin-top: 25px;
}

.phan_loai{
    background: linear-gradient(to left, #a0a093 , #e2e2e2);
    border-radius: 12px;
    position: absolute;
    top: 0;
    left: 0;
    padding: 16px;
    font-weight: bold;
}

.block_camdo > table{
    margin-left: 69px;
}
</style>